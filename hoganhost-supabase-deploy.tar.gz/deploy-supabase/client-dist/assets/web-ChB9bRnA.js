import{W as n}from"./index-BomUaW_E.js";class r extends n{async show(e){}async hide(e){}}export{r as SplashScreenWeb};
//# sourceMappingURL=web-ChB9bRnA.js.map
